<?php
session_start();
session_destroy();
echo "<script>alert('Berhasil logout dari TEL-CARE!'); window.location='../index.php';</script>";